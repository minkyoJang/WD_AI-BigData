setInterval(function () {
    for (var i = 0; i < blockUrls.length; i++) {
        $('div.search-result-card.tw-align-items-center.tw-flex > div.search-result-card__img-wrapper.tw-align-items-center.tw-flex.tw-flex-shrink-0.tw-justify-content-center > a[href="' + blockUrls[i] + '"]').parent('div').parent('div').parent('div').parent('div').click(function () {
            return false;
        });
        //twitch search page -> bj channel disabled click event

        $('div.search-result-card.tw-flex > a[href="' + blockUrls[i] + '"]').parent('div').parent('div').parent('div').click(function () {
            return false;
        });
        //twitch search page videos disabled click event

        $('div.preview-card > div.tw-relative > a[href="' + blockUrls[i] + '"]').parent('div').parent('div').click(function () {
            return false;
        });
        //twitch bj channel page next video && main page video disabled click event

        $('div.side-nav-card.tw-align-items-center.tw-flex.tw-relative > a[href="' + blockUrls[i] + '"]').parent('div').parent('div').click(function () {
            return false;
        });
        //twitch main page bj disabled click event

        $('div#dismissable.style-scope.ytd-video-renderer > ytd-thumbnail > a[href="' + blockUrls[i] + '"]').parent('ytd-thumbnail').parent('div').fadeOut(4000);
        //youtube search page fadeout

        $('div#contents.style-scope.ytd-item-section-renderer > ytd-channel-renderer > a[href="' + blockUrls[i] + '"]').parent('ytd-channel-renderer').fadeOut(4000);
        //youtube search page -> bj channel fadeout

        $('div#dismissable.style-scope.ytd-grid-video-renderer > ytd-thumbnail > a[href="' + blockUrls[i] + '"]').parent('ytd-thumbnail').parent('div').fadeOut(4000);
        //youtube main page fadeout

        $('div#dismissable.style-scope.ytd-compact-video-renderer > ytd-thumbnail > a[href="' + blockUrls[i] + '"]').parent('ytd-thumbnail').parent('div').fadeOut(4000);
        //youtube next video list fadeout

        $('div.search-result-card.tw-flex > a[href="' + blockUrls[i] + '"]').parent('div').parent('div').parent('div').fadeOut(4000);
        //twitch search page fadeout

        $('div.search-result-card.tw-align-items-center.tw-flex > div.search-result-card__img-wrapper.tw-align-items-center.tw-flex.tw-flex-shrink-0.tw-justify-content-center > a[href="' + blockUrls[i] + '"]').parent('div').parent('div').parent('div').parent('div').fadeOut(4000);
        //twitch search page -> bj channel fadeout

        $('div.preview-card > div.tw-relative > a[href="' + blockUrls[i] + '"]').parent('div').parent('div').fadeOut(4000);
        //twitch bj channel page next video && main page video fadeout

        $('div.side-nav-card.tw-align-items-center.tw-flex.tw-relative > a[href="' + blockUrls[i] + '"]').parent('div').parent('div').fadeOut(4000);
        //twitch main page bj fadeout
    }
}, 300);


