function sayHello(){
    document.body.innerText = "youtube, twitch, afreeca blocking";
}
window.onload = sayHello;