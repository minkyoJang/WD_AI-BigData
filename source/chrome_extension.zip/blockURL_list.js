let blockUrls = [
  '/watch?v=hqqdU2-QwOY',
  '/watch?v=tZrgjGpNh9w',
  '/watch?v=JJcce0IGEPE',
  '/watch?v=vq2EG7dIemA',
  '/watch?v=tE1D80-7HgM',
  '/watch?v=MHCmO-bjIPw',
  '/watch?v=FMum9n1Zs6A',
  '/watch?v=ATzOVlE8LSM',
  '/watch?v=mBEpIqtE8Pg',
  '/watch?v=vSyPwKNFGD0',
  '/watch?v=_M4ON5oJAAM',
  '/watch?v=VxlkPpB4P2I',
  '/user/zilioner83', // youtube channel parameter
  '/watch?v=VcIs0Lvbsj4', //youtube video parameter
  '/hanryang1125/video/465645689', // twitch channel video parameter
  '/hanryang1125/video/459991610',
  '/hanryang1125/video/398296893',
  '/hanryang1125/videos',
  '/videos/466566019', //twitch channel - next video parameter
  '/152472619', // twitch video parameter - please not equal Afreeca
  '/ddahyoni',//twitch bj paramter
  '/lol_ambition',
  '/gk3394', // afreeca bj parameter
  '/43552923', // afreeca vod parameter
  '/46791986',
  '/46826239',
  '/46867780',
  '/46884091',
  '/216514910',
  '/216458693',
  '/216514062',
  '/216514153',
  '/46671620',
  '/46805081',
  '/46642571',
  '/46816969',
  '/46812726',
  '/2541004',
  '/216513904',
  '/216516022',
  '/216515486',
  '/216515978',
  '/216514765',
  '/216516324',
  '/46661669'
];