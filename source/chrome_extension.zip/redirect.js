document.write("<script src='blockURL_list.js'></script>");

let pattern = [
  "https://www.youtube.com/*",
  "https://www.twitch.tv/*",
  "http://play.afreecatv.com/*",
  "http://bj.afreecatv.com/*",
  "http://vod.afreecatv.com/*"
];

// blocking function
function redirect(requestDetails) {
    if (blockUrls.some(el => requestDetails.url.includes(el))) {
        return { cancel: true };
    }
    else {
        return {
            redirectUrl: requestDetails.url
        };
    }
}

chrome.webRequest.onBeforeRequest.addListener(
  redirect,
  {urls : pattern},
  ["blocking"]
);
