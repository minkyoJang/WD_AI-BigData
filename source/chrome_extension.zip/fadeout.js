setInterval(function () {
    for (var i = 0; i < blockUrls.length; i++) {
        $('div.search-result-card.tw-align-items-center.tw-flex > div.search-result-card__img-wrapper.tw-align-items-center.tw-flex.tw-flex-shrink-0.tw-justify-content-center > a[href*="' + blockUrls[i] + '"]').parent('div').parent('div').parent('div').parent('div').click(function () {
            return false;
        });
        //twitch search page -> bj channel disabled click event

        $('div.search-result-card.tw-flex > a[href*="' + blockUrls[i] + '"]').parent('div').parent('div').parent('div').click(function () {
            return false;
        });
        //twitch search page videos disabled click event

        $('div.preview-card > div.tw-relative > a[href*="' + blockUrls[i] + '"]').parent('div').parent('div').click(function () {
            return false;
        });
        //twitch bj channel page next video && main page video disabled click event

        $('div.side-nav-card.tw-align-items-center.tw-flex.tw-relative > a[href*="' + blockUrls[i] + '"]').parent('div').parent('div').click(function () {
            return false;
        });
        //twitch main page bj disabled click event

        $('div#dismissable.style-scope.ytd-video-renderer > ytd-thumbnail > a[href*="' + blockUrls[i] + '"]').parent('ytd-thumbnail').parent('div').fadeOut(4000);
        //youtube search page fadeout

        $('div#contents.style-scope.ytd-item-section-renderer > ytd-channel-renderer > a[href*="' + blockUrls[i] + '"]').parent('ytd-channel-renderer').fadeOut(4000);
        //youtube search page -> bj channel fadeout

        $('div#dismissable.style-scope.ytd-grid-video-renderer > ytd-thumbnail > a[href*="' + blockUrls[i] + '"]').parent('ytd-thumbnail').parent('div').fadeOut(4000);
        //youtube main page fadeout

        $('div#dismissable.style-scope.ytd-compact-video-renderer > ytd-thumbnail > a[href*="' + blockUrls[i] + '"]').parent('ytd-thumbnail').parent('div').fadeOut(4000);
        //youtube next video list fadeout

        $('div.search-result-card.tw-flex > a[href*="' + blockUrls[i] + '"]').parent('div').parent('div').parent('div').fadeOut(4000);
        //twitch search page fadeout

        $('div.search-result-card.tw-align-items-center.tw-flex > div.search-result-card__img-wrapper.tw-align-items-center.tw-flex.tw-flex-shrink-0.tw-justify-content-center > a[href*="' + blockUrls[i] + '"]').parent('div').parent('div').parent('div').parent('div').fadeOut(4000);
        //twitch search page -> bj channel fadeout

        $('div.preview-card > div.tw-relative > a[href*="' + blockUrls[i] + '"]').parent('div').parent('div').fadeOut(4000);
        //twitch bj channel page next video && main page video fadeout

        $('div.side-nav-card.tw-align-items-center.tw-flex.tw-relative > a[href*="' + blockUrls[i] + '"]').parent('div').parent('div').fadeOut(4000);
        //twitch main page bj fadeout

        $('ul#vodSlider > li > div.cast_box > a[href*="' + blockUrls[i] + '"]').parent('div').parent('li').fadeOut(4000);
        //afreeca main page vod video fadeout

        $('div.more_vod > ul > li > a[href*="' + blockUrls[i] + '"]').parent('li').fadeOut(4000);
        //afreeca main page vod-tab video fadeout

        $('ul#liveSlider > li > div.cast_box > a[href*="' + blockUrls[i] + '"]').parent('div').parent('li').fadeOut(4000);
        //afreeca main page live video fadeout

        $('div#broadlist_area > div.listarea > ul > li > div.cast_box > a[href*="' + blockUrls[i] + '"]').parent('div').parent('li').fadeOut(4000);
        //afreeca main page total video fadeout

        $('div.ranking-list a[href*="' + blockUrls[i] + '"]').parent('li').fadeOut(4000);
        //afreeca main page star-rank tab chicken-gak fadeout

        $('div.ranking-list a[href*="' + blockUrls[i] + '"]').parent('dd').fadeOut(4000);
        //afreeca main page star-rank tab others fadeout

        $('div.direct_area > dl.detail > dd.url > a:contains("' + blockUrls[i] + '")').parent('dd').parent('dl').parent('div').fadeOut(4000);
        //afreeca search page video direct watch fadeout

        $('div#divProfileRoot > div.profile_wrap > div.detail > div.pr > dl > dt > span > a[href*="' + blockUrls[i] + '"]').parent('span').parent('dt').parent('dl').parent('div').parent('div').parent('div').parent('div').fadeOut(4000);
        //afreeca search page bj profile fadeout

        $('div#broad_list > ul.onair_list > li.bj > a[href*="' + blockUrls[i] + '"]').parent('li').parent('ul').parent('div').fadeOut(4000);
        //afreeca search page live video fadeout

        $('div#video_list > ul.vod_w > li > a[href*="' + blockUrls[i] + '"]').parent('li').fadeOut(4000);
        //afreeca search page vod video fadeout

        $('ul#detailVideoPageList > li > div.tit > a[href*="' + blockUrls[i] + '"]').parent('div').parent('li').fadeOut(4000);
        //afreeca search page vod video fadeout

        $('div#bj_list > ul.bj_list > li.tit > a[href*="' + blockUrls[i] + '"]').parent('li').parent('ul').parent('div').fadeOut(4000);
        //afreeca search page bj video fadeout
    }
}, 300);


